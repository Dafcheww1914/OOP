﻿using System;

namespace ArenaGame
{
    public class Arena
    {
        public Hero HeroA { get; private set; }
        public Hero HeroB { get; private set; }

        public Arena(Hero a, Hero b)
        {
            HeroA = a;
            HeroB = b;
        }

        public Hero Battle()
        {
            Hero attacker, defender;
            if (new Random().Next(2) == 0)
            {
                attacker = HeroA;
                defender = HeroB;
            }
            else
            {
                attacker = HeroB;
                defender = HeroA;
            }
            while (true)
            {
                int damage = attacker.Attack();
                defender.TakeDamage(damage);
                if (defender.IsDead) return attacker;
              
                Hero tmp = attacker;
                attacker = defender;
                defender = tmp;
            }
        }
    }

    static void Main(string[] args)
    {
        Hero ahri = new Ahri();
        Hero aphelios = new Aphelios();
        Hero caitlyn = new Caitlyn();

        Weapon axe = new Axe();
        Weapon shuriken = new Shuriken();
        Weapon sword = new Sword();

        ahri.EquippedWeapon = axe;
        aphelios.EquippedWeapon = shuriken;
        caitlyn.EquippedWeapon = sword;

        Arena arena = new Arena(ahri, aphelios);
        Hero winner = arena.Battle();
        Console.WriteLine($"The winner is {winner.Name}");

        arena = new Arena(caitlyn, ahri);
        winner = arena.Battle();
        Console.WriteLine($"The winner is {winner.Name}");
    }
}


