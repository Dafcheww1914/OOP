﻿using System;

namespace ArenaGame
{
    public class Caitlyn : Hero
    {
        public Caitlyn() : this("Caitlyn") { }

        public Caitlyn(string name) : base(name) { }

        public override int Attack()
        {
            int attack = base.Attack();
          
            if (ThrowDice(30))
            {
                Console.WriteLine($"{Name} performed a headshot!");
                attack = attack * 2;
            }
            return attack;
        }

        public override void TakeDamage(int incomingDamage)
        {
            
            incomingDamage = incomingDamage * 4 / 5;
            base.TakeDamage(incomingDamage);
        }
    }
}
