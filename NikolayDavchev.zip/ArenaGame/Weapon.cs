﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArenaGame
{
    public abstract class Weapon
    {
        public string Name { get; private set; }
        public int AttackBonus { get; private set; }

        public Weapon(string name, int attackBonus)
        {
            Name = name;
            AttackBonus = attackBonus;
        }

        public abstract int ApplySpecialEffect(int attackValue);
    }

    public class Axe : Weapon
    {
        public Axe() : base("Axe", 20) { }

        public override int ApplySpecialEffect(int attackValue)
        {
           
            if (new Random().Next(100) < 10)
            {
                return attackValue * 2;
            }
            return attackValue;
        }
    }

    public class Shuriken : Weapon
    {
        public Shuriken() : base("Shuriken", 10) { }

        public override int ApplySpecialEffect(int attackValue)
        {
           
            if (new Random().Next(100) < 20)
            {
                return attackValue * 3;
            }
            return attackValue;
        }
    }

    public class Sword : Weapon
    {
        public Sword() : base("Sword", 15) { }

        public override int ApplySpecialEffect(int attackValue)
        {
            
            if (new Random().Next(100) < 15)
            {
                return attackValue * 3 / 2;
            }
            return attackValue;
        }
    }
}
