﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArenaGame
{
    public class Aphelios : Hero
    {
        public Aphelios() : this("Aphelios") { }

        public Aphelios(string name) : base(name) { }

        public override int Attack()
        {
            int attack = base.Attack();
            
            if (ThrowDice(20))
            {
                Console.WriteLine($"{Name} used a special attack!");
                attack = attack * 3 / 2;
            }
            return attack;
        }

        public override void TakeDamage(int incomingDamage)
        {
          
            if (ThrowDice(15))
            {
                Console.WriteLine($"{Name} dodged the attack!");
                incomingDamage = 0;
            }
            base.TakeDamage(incomingDamage);
        }
    }
}
