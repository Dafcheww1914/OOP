﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArenaGame
{
    public class Ahri : Hero
    {
        public Ahri() : this("Ahri") { }

        public Ahri(string name) : base(name) { }

        public override int Attack()
        {
            int attack = base.Attack();
            if (ThrowDice(25))
            {
                Console.WriteLine($"{Name} charmed the enemy, reducing their next attack!");
                attack = attack * 2;
            }
            return attack;
        }

        public override void TakeDamage(int incomingDamage)
        {
            int healAmount = incomingDamage / 10;
            Heal(healAmount);
            base.TakeDamage(incomingDamage);
        }
    }
}
